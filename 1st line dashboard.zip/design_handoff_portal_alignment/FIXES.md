# FIXES — 1line Portal design system alignment

19 tasks in 5 phases. Ordered by dependency. Read `README.md` first, especially **"Verify before you edit."**

Legend: `[C#]` / `[M#]` = finding in `Design Audit.html`. `[D#]` / `[W#]` = finding in `Deployment Review.html`.

---

## Phase 1 — Decisions and shared primitives

Everything downstream depends on this phase. Do not skip ahead.

### P1-T1 — Command palette: ship or remove  `[M1]`
**BLOCKED — needs product decision.**

`frontend/src/App.jsx`, TopBar. There is a `⌘K` "Jump to page…" button, fully styled with a kbd hint, that does nothing. It is a dead affordance in the most prominent position in the chrome.

Two acceptable resolutions:
- **A** — implement a minimal palette: centred overlay, lists the nav pages, `↑`/`↓` to move, `Enter` to navigate, `Esc` to close, opens on `⌘K`/`Ctrl+K`.
- **B** — replace the wide button with a 28×28 icon-only ghost button (Lucide `search`), no kbd hint, until the palette is real.

**Do not implement either without confirmation.** Report this task back and continue with P1-T2.

> Note: if the sidebar is collapsed or absent by default in the deployed build (it is not visible in any reviewed screenshot), option A becomes considerably more important — the palette would be the primary means of navigation.

---

### P1-T2 — Add the missing display type classes  `[C2]`

`frontend/src/theme.js` → `getGlobalCSS()`.

`--font-display` (Source Serif 4) is defined and loaded, and pages apply it through ad-hoc inline styles. The utility classes that should own that recipe exist in `colors_and_type.css` but are missing from the runtime CSS, so every hero reinvents its own heading and letter-spacing drifts.

Add these rules verbatim. Values come from `colors_and_type.css` — do not adjust them:

```css
.t-display-lg{font-family:var(--font-display);font-size:var(--fs-display-lg);font-weight:var(--fw-regular);letter-spacing:var(--ls-display);line-height:var(--lh-display);color:var(--text)}
.t-display{font-family:var(--font-display);font-size:var(--fs-display);font-weight:var(--fw-regular);letter-spacing:var(--ls-display);line-height:var(--lh-display);color:var(--text)}
.t-h1{font-family:var(--font-display);font-size:var(--fs-h1);font-weight:var(--fw-regular);letter-spacing:var(--ls-h1);line-height:var(--lh-heading);color:var(--text)}
.t-h2{font-family:var(--font-sans);font-size:var(--fs-h2);font-weight:var(--fw-semibold);letter-spacing:var(--ls-h2);line-height:var(--lh-heading);color:var(--text)}
.t-h3{font-family:var(--font-sans);font-size:var(--fs-h3);font-weight:var(--fw-semibold);letter-spacing:var(--ls-tight);line-height:var(--lh-heading);color:var(--text)}
.t-h4{font-family:var(--font-sans);font-size:var(--fs-h4);font-weight:var(--fw-semibold);line-height:var(--lh-heading);color:var(--text)}
```

Check first whether any of these already exist — `.t-h3` is referenced by an existing `SectionHeader`, so some may be present. Add only what's missing.

**Done when:** all six classes resolve in DevTools, and applying `className="t-display"` to any element renders Source Serif 4 at 44px.

---

### P1-T3 — Extract a shared `<PageHeader>`  `[D1]`

**This is the highest-value task in the package.** New export in `frontend/src/UI.jsx`.

Five pages currently build their own header inline, producing four different typographic treatments:

| Page | Current treatment |
|---|---|
| Home | mono date eyebrow → **serif** greeting → sans sub → button pair right |
| Schedule | **serif** title → sans sub, with a 7-button toolbar inline beside the title |
| Runbooks | **serif** title → sans sub → search + primary right |
| Mail | **sans bold** title + count pill → 3 buttons right |
| Tickets | **sans bold** title → sans sub → segmented control right |

Mail and Tickets read as a different product. The serif is the brand's voice; a page that opts out looks unfinished rather than deliberate.

Build:

```jsx
export function PageHeader({ eyebrow, title, subtitle, meta, actions, children }) {
  // Layout:
  //   optional eyebrow      — className="t-eyebrow", font-mono, margin-bottom var(--space-2)
  //   title row             — flex, align-items baseline, gap var(--space-3), justify-content space-between
  //     left:  <h1 className="t-h1">{title}</h1> + optional {meta} (count pill etc.)
  //     right: {actions} — flex row, gap var(--space-2)
  //   optional subtitle     — className="t-body-sm", margin-top var(--space-2)
  //   optional {children}   — secondary toolbar row, margin-top var(--space-4)
}
```

Rules the component enforces:
- Title is **always** `.t-h1` (serif). No page opts out.
- Subtitle is **always** `.t-body-sm`.
- Actions are **always** a right-aligned flex row with `gap: var(--space-2)`.
- A secondary toolbar goes in `children`, on its own row below the header — never inline beside the title.

**Done when:** the component exists and is exported. Migration happens in Phase 3.

---

### P1-T4 — Add a `formatState()` helper  `[D6]`

`frontend/src/UI.jsx` or a new `frontend/src/format.js` — your call, but export it from one place.

Ticket `#82431` renders as `In progress` on Home and `in_progress` on the Tickets table. Same field, one click apart.

```js
export function formatState(s) {
  // 'in_progress' → 'In progress'
  // snake_case → sentence case: split on _, lowercase all, capitalise first char only
}
```

Handle `open`, `closed`, `paused`, `in_progress`, `new`, `pending_close` and degrade gracefully on unknown values (never return `undefined` or throw).

**Done when:** `formatState('in_progress') === 'In progress'` and `formatState('closed') === 'Closed'`.

---

## Phase 2 — Shell and brand

### P2-T1 — Fix the webfont loading  `[C1]`

`frontend/index.html`.

The shell requests **DM Sans**, which the runtime CSS never references — a render-blocking request for a font that never paints. The README already flags it as dead code.

Replace the existing Google Fonts `<link>` with:

```html
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
```

Then check `theme.js → getGlobalCSS()` for a duplicate `@import` of the same families and **remove it**. A font `@import` inside JS-injected CSS doesn't start until React boots, which widens the FOIT window; the `<link>` in `index.html` is the only one that should exist.

**Done when:** DevTools → Network → Fonts shows requests for exactly Inter, Source Serif 4 and JetBrains Mono. `grep -ri "dm sans\|DM+Sans" frontend/` returns nothing.

---

### P2-T2 — Rename "Support Portal" → "1line Portal"  `[C3a]`

The product is **1line Portal**. `frontend/index.html` `<title>` and the `LoginPage.jsx` hero `<h1>` both still say "Support Portal", a v1 holdover. This is the first text every user reads.

- `index.html`: `<title>1line Portal</title>`
- `LoginPage.jsx`: `<h1 className="t-h1">1line Portal</h1>` (uses the class from P1-T2)
- Update `README.md` / `USER_GUIDE.md` references

**Done when:** `grep -ri "support portal" .` returns hits only in `CHANGELOG.md` (historical entries are fine to keep).

---

### P2-T3 — Replace the emoji favicon with the brand mark  `[C3b]`

Copy `assets/logo-pc.svg` from this bundle to `frontend/public/logo-pc.svg`.

`frontend/index.html` — replace the `data:image/svg+xml` ⚡ favicon:

```html
<link rel="icon" type="image/svg+xml" href="/logo-pc.svg" />
```

**Done when:** the tab icon is the blue-to-pink PC monitor, not a lightning bolt. Test in a private window — favicons cache aggressively.

---

### P2-T4 — Sidebar workspace pill: real brand, not placeholder  `[C4]`

`frontend/src/App.jsx`, sidebar workspace pill.

Currently a generic 2×2 grid icon plus the kanji `基盤` — placeholder content in the most prominent slot in the chrome.

```jsx
<img src="/logo-pc.svg" width="14" height="14" alt="" />
<div style={{ fontSize: 14, fontWeight: 600 }}>1line</div>
<div style={{ fontSize: 10, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>prod</div>
```

Keep the chevron and the existing hover state.

**Done when:** the pill reads PC-monitor mark + `1line` + uppercase mono `PROD`.

---

### P2-T5 — Use the shared `<Avatar>` in the sidebar  `[C5]`

**Verify first — this may already be fixed.** Every avatar in the reviewed screenshots used the correct recipe.

`frontend/src/App.jsx`, user button at the sidebar bottom. If it still builds an avatar inline by concatenating hex with alpha suffixes (`color + '22'`, `color + '44'`) and colouring the initial with the name colour, replace it:

```jsx
<Avatar name={user.display_name || user.username} color={user.name_color} size={30} />
```

The shared component renders solid name-colour fill + white initial, which is the spec and what every other surface shows. The inline version is the only pastel, bordered avatar in the product.

**Done when:** the sidebar avatar is visually identical to the Home page avatars — solid fill, white initial, no border.

---

### P2-T6 — Topbar: translucent surface + backdrop blur  `[C6]`

`frontend/src/App.jsx`, `TopBar`. The sticky header uses the same colour as the content beneath it, so scrolling a dense page gives no separation between chrome and content.

```jsx
background: 'color-mix(in srgb, var(--surface) 78%, transparent)',
backdropFilter: 'blur(12px)',
WebkitBackdropFilter: 'blur(12px)',
```

Keep `height: 48`, the `borderBottom`, and the sticky positioning as they are.

**Done when:** scrolling the Schedule page shows content blurring softly behind the topbar.

---

### P2-T7 — Notification badge halo  `[M5]`

`frontend/src/App.jsx`, bell button badge. Its 2px border is `var(--bg)` — intended as a halo cutting the badge out of the surface behind it, but invisible because the topbar was also `--bg`. After P2-T6 the topbar is `--surface`, so switch the badge border to `var(--surface)`.

**Done when:** the red badge has a visible halo, like a sticker cut out of the topbar.

---

## Phase 3 — Migrate pages onto the primitives

Each task replaces bespoke markup with the Phase 1 components. Do these one page at a time and check the page renders before moving on.

### P3-T1 — Migrate all five pages to `<PageHeader>`  `[D1]`

Replace the inline header in each of `HomePage.jsx`, `MailPage.jsx`, `TicketsPage.jsx`, `SchedulePage.jsx`, `RunbooksPage.jsx`.

Per-page mapping:

- **Home** — `eyebrow` = the mono date/time string; `title` = the greeting (keep the accent-coloured name span); `subtitle` = shift/mail summary; `actions` = *My shifts* + *Open mail*.
- **Mail** — `title="Mail"`; `meta` = the `500 logs` count pill; `actions` = *Rules*, *Mailbox*, *Sync IMAP*. **The title changes from sans bold to serif — this is the point of the task.**
- **Tickets** — `title="Tickets"`; `subtitle` = the Zammad sync line; `actions` = the Tickets/Event log segmented control. **Also changes to serif.**
- **Schedule** — `title="Schedule"`; `subtitle` = the week range + published state; the 7-button toolbar (*Week/Month*, `<`, *Today*, `>`, *Time off*, *+ Shift*, *Generate*, *Publish*, *Clear drafts*) moves into `children` as its own row.
- **Runbooks** — `title="Runbooks"`; `subtitle` = `53 playbooks · used 21 times`; `actions` = search + *New runbook*.

**Done when:** all five page titles render in Source Serif 4 at the same size, all five action rows are right-aligned with identical gaps, and the Schedule toolbar sits on its own row below the title rather than beside it.

---

### P3-T2 — Use `formatState()` in the Tickets table  `[D6]`

`frontend/src/TicketsPage.jsx`, state pill. Wrap the raw value in the P1-T4 helper. Keep the existing pill colours — blue for in-progress, green for closed are already correct.

Check `HomePage.jsx` too and route it through the same helper so the two can't drift again.

**Done when:** ticket `#82431` reads `In progress` in both places.

---

### P3-T3 — Snap HomePage hero to tokens  `[C7]`

`frontend/src/pages/HomePage.jsx`.

Two hard-coded values that fight the token scale:
- Greeting uses `letterSpacing: '-0.045em'` — more than 2× tighter than `--ls-display` (`-0.02em`). Prefer `className="t-display"` and delete the inline recipe entirely. The type will look slightly looser; that is correct.
- Email subject lines use `fontWeight: 650`, which is not a real Inter weight and silently rounds to 600. Use `var(--fw-semibold)`.

**Done when:** no hard-coded `em` letter-spacing or numeric font-weight remains in this file — only `var(--*)` references or type classes.

---

### P3-T4 — Normalise card and modal header sizes  `[M4]`

Currently: `Overlay` title is 14px/700, Home card titles 22px/600, `SectionHeader` uses `.t-h3` (18px), MetricCard label is an 11px eyebrow. The scale is defined; start picking from it.

- Card headers → `className="t-h3"`
- Modal / overlay headers → `className="t-h4"`
- Home's 22px hero card titles are the one legitimate exception — **leave them**, and add a one-line comment saying why.

**Done when:** grep for inline `fontSize:` on card and overlay headers returns only the documented Home exception.

---

## Phase 4 — Component and page detail

### P4-T1 — Fix the Assistant panel header overlap  `[D2]`

**Real bug, not a style preference.** The Assistant panel's header (avatar, "Assistant", the `schedule · time off · runbooks · mail review` capability line) is translucent and pinned over the scroll area, so messages scroll *underneath it* and get sliced mid-word.

1. Give the scroll container `padding-top` equal to the header height (~76px) instead of letting the header float over content.
2. Put the header on `var(--surface-elevated)` with `backdrop-filter: blur(12px)` — same recipe as P2-T6, so the blur is a system behaviour rather than a one-off.
3. Drop the per-message avatar for consecutive assistant messages (it currently appears in the header *and* beside the same message).
4. Move message bubbles to `var(--surface-elevated)` so they read as distinct objects — currently the bubble and panel background are nearly identical.

**Done when:** scrolling the message list to the top shows the first message fully, with no text sliding under the header.

---

### P4-T2 — Tone down the Assistant launcher  `[D4]`

`frontend/src/App.jsx`, the fixed bottom-right FAB.

A 56px solid-accent circle is the highest-contrast element on every screen — it pulls harder than *Open mail*, *Sync IMAP* and *Run*. For a persistent, never-urgent utility that is inverted: the loudest thing on screen should be what the current page wants you to do.

- Fill → `var(--surface-elevated)`, `border: 1px solid var(--border-strong)`
- Accent stays on the ASCII face itself, and on hover
- Add `aria-label="Assistant"` and a hover tooltip (`Assistant · ⌘J` if you wire the shortcut, otherwise just `Assistant`)

**Keep the cat.** It is the product's personality and it belongs here — see `W3` in `Deployment Review.html`. This task lowers its volume, it does not remove it. The open-state X button already has the right treatment; match it.

---

### P4-T3 — Schedule shift chips: use the user-colour tokens  `[D5]`

`frontend/src/pages/SchedulePage.jsx`.

Chips currently use raw saturated hues — hot pure red, vivid violet, bright cyan, bright green. Against `#1c2030` these are the loudest thing on the page, louder than the accent. `colors_and_type.css` ships a deliberately retuned palette for exactly this and it isn't being used:

```
--user-blue: #1a73e8   --user-red: #d93025    --user-green: #188038   --user-amber: #e37400
--user-violet: #6f42c1 --user-pink: #ad1457   --user-cyan: #007b83    --user-lime: #57721c
```

1. Map shift owners onto `--user-*` tokens rather than arbitrary hues.
2. In dark mode drop the chip fill to ~12% alpha of the owner hue and keep the left strip at full opacity. The chip is currently a third card recipe — tinted gradient fill *plus* left strip *plus* solid avatar square — where cards elsewhere use surface + strip only.

**Done when:** the week grid reads as calm coloured lanes rather than six competing signals, and Tuesday's "today" column highlight is visible again (it is currently drowned out).

---

### P4-T4 — Replace Schedule row emoji with icons  `[D3]`

`frontend/src/pages/SchedulePage.jsx`. The Day / Night / Office row markers are colour emoji (yellow sun, purple moon, orange grid). These are chrome, not data, and the token file's own header says *"No emoji. Lucide icons only."* They also render differently per OS.

Swap for Lucide `sun` / `moon` / `layout-grid` at `var(--text-secondary)`. Let the chip colour carry the meaning.

---

### P4-T5 — Mail category emoji  `[D3]`

`frontend/src/pages/MailPage.jsx`, category rail.

The categories show colour emoji (🦠 Kaspersky, 🔴 Adobe, 🟡 Yandex Support, 🔵 Onboarding, 🔵 Offboarding, 🖥 Backup Alerts) each paired with a `#` in accent — two competing glyph systems on one 20px row.

**If these emoji are user-authored data**, they are legitimate: keep them, but render each in a fixed-width slot (`width: 16px`, centred) so labels align, and **drop the `#`** — the emoji already marks the row.

**If they are hard-coded in the source**, replace with Lucide icons at `var(--text-secondary)` and keep the `#`.

Check which before editing.

---

### P4-T6 — Tickets table column widths  `[D7]`

`frontend/src/pages/TicketsPage.jsx`. At ~2300px wide, `aleksandr.semeno…` and `ahmed.abdelmone…` are both clipped while Title and Updated have room to spare. Truncating identity at full desktop width is a sizing bug, and email is the one column where the tail carries the meaning.

- Title → `minmax(240px, 1fr)`
- Assignee / Customer → `minmax(200px, auto)`
- Add `title={fullValue}` on any cell that can truncate, so the value is always hoverable

**Done when:** at 1920px and above, no assignee or customer value is clipped.

---

### P4-T7 — Toast: strip instead of coloured border  `[M3]`

`frontend/src/UI.jsx`, `<Toast>`. Cards, modals and active nav items all carry their accent as a 3px strip positioned absolutely inside the chrome. Toast is the lone violator with `borderLeft: 3px solid accent`.

```jsx
// container: keep border: '1px solid var(--border)', add position: 'relative'
<span style={{ position: 'absolute', left: 0, top: 10, bottom: 10, width: 3, background: accent, borderRadius: '0 3px 3px 0' }} />
```

**Done when:** a fired toast shows a short strip inset from top and bottom, matching the Card recipe — not a border running the full height.

---

### P4-T8 — Avatar default radius  `[M2]`

`frontend/src/UI.jsx`, `<Avatar>` default prop. Change the default from `--radius-sm` (6px) to `--radius` (8px). The system specifies avatars read softer than buttons; at 6px a 30px avatar looks like a 30px button sitting next to it.

**Done when:** avatars have visibly rounder corners than adjacent buttons — not pills, just softer.

---

## Phase 5 — Documentation

### P5-T1 — Record the brand-voice decision  `[W3]`
**BLOCKED — needs product decision, but the recommendation is strong.**

The system currently contains two documented voices. `README.md` describes v1: emoji nav icons, a constellation background, a custom triangular cursor, "a spark of cuteness." `colors_and_type.css` and `theme.js` describe **v2 — engineer-tool redesign — "no background patterns, no emoji, Lucide icons only."**

The deployment has already resolved this in practice, and better than either documented option: **the personality lives in the assistant** — an ASCII cat with a real voice (`/handover` in a mono chip, "Ask me in English or Russian!", capabilities written as tasks) — while the operational chrome stays flat and quiet. A constellation behind a ticket table grates after ten hours; a cat that answers "what did we do this week?" does not.

Add a short doc comment at the top of `theme.js` stating it, so the next contributor doesn't reopen the constellation question:

> **Brand voice.** v2 surfaces: flat, quiet, no background patterns, Lucide icons, serif reserved for display type. Personality is confined to the Assistant — its ASCII-cat identity and conversational copy are deliberate and in scope. Do not reintroduce v1's constellation background, custom cursor, or emoji nav icons.

Confirm the wording with the team before committing, then update `README.md` to match so the two files stop disagreeing.

---

## Summary

| Phase | Tasks | Blocked |
|---|---|---|
| 1 — Decisions and primitives | 4 | P1-T1 |
| 2 — Shell and brand | 7 | — |
| 3 — Migrate pages | 4 | — |
| 4 — Component detail | 8 | — |
| 5 — Documentation | 1 | P5-T1 |

**If you only do three things:** P1-T3 + P3-T1 (one page-header component, five pages migrated — the single biggest visual win), P4-T1 (a genuine bug clipping message text), and P1-T2 (the type classes everything else depends on).
