# Handoff: 1line Portal — Design System Alignment

## Overview

This package contains a design-system alignment review of `iwanderalone/1stline-magic-portal` and an ordered list of fixes to bring the deployed portal in line with the 1line Portal Design System (v2 tokens).

**This is not a design to recreate.** The app already exists and is deployed. Every task below is a targeted correction to existing files. Do not redesign, do not restructure, do not "improve" adjacent code — each task has a scope and an acceptance criterion.

## About the files in this bundle

- **`FIXES.md`** — the implementation task list. This is the working document. Read it first.
- **`Design Audit.html`** — source-code audit (14 findings, C/M-prefixed). Reference for *why* each change matters.
- **`Deployment Review.html`** — rendered-UI audit of 5 logged-in screens, dark theme (D-prefixed findings). Reference for the issues only visible at runtime.
- **`Ship Checklist.html`** — the same fixes as interactive tickets with before/after diffs.
- **`colors_and_type.css`** — the design system's canonical token file. **This is the source of truth for every value.** The repo's runtime tokens live in `frontend/src/theme.js`; where the two disagree, this file wins.

The three HTML files are **review documents**, not code to ship. Open them in a browser for context.

## Critical: verify before you edit

The audit was written from source at an earlier commit; the deployment screenshots then showed that **some findings were already fixed**. Specifically:

- The serif display system (`--font-display`) *is* applied on Home, Schedule and Runbooks. Finding C2 is partly resolved.
- Avatars in the reviewed screens use the correct solid-fill + white-initial recipe. Finding C5 may already be done.

**Before implementing any task, read the current state of the named file.** If a fix is already in place, mark it done and move on. Do not revert working code to match a diff in this document.

## Fidelity

**High-fidelity, token-based.** Every value in `FIXES.md` is either an exact CSS custom property from `colors_and_type.css` or a specific numeric value. Do not substitute approximations. Where a task says `var(--surface-elevated)`, use that token — not a hex value that currently resolves to the same colour.

## Target environment

React 18 + Vite, plain JSX (no TypeScript), styling via inline `style={{}}` objects and CSS custom properties injected by `theme.js → getGlobalCSS()`. There is no CSS-in-JS library and no Tailwind. **Match this.** Do not introduce a styling dependency to implement these fixes.

Relevant files:

```
frontend/index.html
frontend/src/theme.js          — getGlobalCSS(), token definitions
frontend/src/App.jsx           — shell: sidebar, TopBar, Assistant FAB
frontend/src/UI.jsx            — shared components: Avatar, Toast, Card, Overlay
frontend/src/Icons.jsx         — icon set
frontend/src/pages/
  HomePage.jsx
  LoginPage.jsx
  MailPage.jsx
  TicketsPage.jsx
  SchedulePage.jsx
  RunbooksPage.jsx
```

## Ordering

`FIXES.md` is ordered by dependency, not severity. Phases 1–2 create the shared primitives that later phases consume — implementing Phase 4 before Phase 2 means writing code you then delete. Work top to bottom.

Two tasks (P1-T1 and P5-T1) require a human decision before implementation and are marked **BLOCKED — needs product decision**. Skip them and report them back rather than guessing.

## Verification

Each task has a **Done when** clause. These are written to be checkable — a grep result, a DevTools observation, or a specific visual state. After each phase, run the app and confirm the phase's criteria before continuing.

There are no tests in this repo covering visual output. Do not add a test framework as part of this work; if you want to verify a token refactor didn't change rendering, take before/after screenshots.

## Screenshots

`screenshots/` — the deployed UI, dark theme, captured 25 Aug 2026. These are **the current state, not a target.** They are evidence for the findings, not designs to match.

| File | Shows | Cited by |
|---|---|---|
| `01-home.png` | Home — greeting, metric strip, Needs attention / Shift context | D1, P3-T3, W1 |
| `02-mail.png` | Mail — sans-bold title, category rail with emoji, empty state | D1, P4-T5, W2 |
| `03-tickets.png` | Tickets — sans-bold title, `in_progress` pill, truncated columns | D1, P3-T2, P4-T6 |
| `04-schedule.png` | Schedule — serif title, inline toolbar, saturated shift chips | D1, P4-T3, P4-T4 |
| `05-runbooks.png` | Runbooks — serif title, runbook detail | D1 |
| `06-assistant-panel.png` | Assistant open — header clipping the message beneath it | D2, P4-T1, W3 |

Two things to read from these directly:

- **Compare the five page titles side by side** (01, 02, 03, 04, 05). Home/Schedule/Runbooks are serif; Mail/Tickets are sans bold. That inconsistency is task P1-T3 + P3-T1 and it is easiest to see as a set.
- **In `06-assistant-panel.png`, look at the top of the message list.** "Time off" is sliced horizontally mid-word by the panel header. That is the bug in P4-T1, not a capture artifact.

Note the screenshots are all **dark theme**. The source audit assumed light. If light is the shipping default, the token-based fixes still apply unchanged, but the contrast judgements in P4-T2 and P4-T3 should be re-checked in light mode.

## Assets

`logo-pc.svg` — the brand mark (PC monitor, accent gradient). It is referenced by tasks P2-T2 and P2-T3. It is included in this bundle at `assets/logo-pc.svg`; it belongs at `frontend/public/logo-pc.svg` so Vite serves it from `/logo-pc.svg`.

No other new assets are required. Every icon needed already exists in `Icons.jsx` or is a standard Lucide glyph name.
